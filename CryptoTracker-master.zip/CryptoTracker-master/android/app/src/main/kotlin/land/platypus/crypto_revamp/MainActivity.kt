package land.platypus.crypto_revamp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
